from app.application.engine.validation.validationStatus import ValidationResult


class DSLResolver:

    def resolve_patch(self, node, validation: ValidationResult) -> str | None:
        """
        По типу ошибки из ValidationResult возвращает ключ DSL-патча
        объявленного на ноде. None если патча нет.
        """
        if not validation.reason:
            return None

        return node.dsl_patches.get(validation.reason)

    def update(self, dsl_keys: list[str], patch_key: str | None) -> list[str]:
        """
        Добавляет patch_key к списку dsl_keys если он есть.
        """
        if not patch_key or patch_key in dsl_keys:
            return dsl_keys

        return dsl_keys + [patch_key]